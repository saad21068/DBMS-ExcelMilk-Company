create table cart(
	pid INT,
	pname VARCHAR(50),
	quantity INT,
	price decimal(10,2),
	deliveryperiod INT,
	productdesc VARCHAR(50)
);
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (1, null, 1, 66.00,3, 'Granite');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (2, null, 2, 32.00, 1, 'Glass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (3, null, 3, 10.67, 5, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (4, null, 4, 61.10, 4, 'Granite');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (5, null, 5, 17.3, 6, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (6, null, 6, 98.36, 7, 'Stone');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (7, null, 7, 13.31, 1, 'Aluminum');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (8, null, 8, 25.39,4, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (9, null, 9, 19.06, 2, 'Plexiglass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (10, null, 10, 45.01, 10, 'Aluminum');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (11, null, 11, 8.59, 4, 'Plastic');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (12, null, 12, 73.37, 9, 'Vinyl');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (13, null, 13, 45.16, 4, 'Granite');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (14, null, 14, 89.82, 2, 'Vinyl');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (15, null, 15, 84.97, 6, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (16, null, 16, 37.44, 2, 'Aluminum');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (17, null, 17, 97.35, 2, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (18, null, 18, 39.16, 7, 'Granite');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (19, null, 19, 47.31, 10, 'Granite');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (20, null, 20, 77.92, 1, 'Aluminum');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (21, null, 21, 14.93, 4, 'Plastic');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (22, null, 22, 6.55, 6, 'Steel');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (23, null, 23, 94.50, 4, 'Vinyl');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (24, null, 24, 16.40, 5, 'Plexiglass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (25, null, 25, 66.02, 9, 'Plexiglass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (26, null, 26, 28.54, 7, 'Glass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (27, null, 27, 77.97, 2, 'Plexiglass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (28, null, 28, 66.53, 1, 'Stone');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (29, null, 29, 7.02, 5, 'Plexiglass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (30, null, 30, 94.36, 3, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (31, null, 31, 28.56, 2, 'Vinyl');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (32, null, 32, 71.52, 1, 'Stone');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (33, null, 33, 74.72, 5, 'Vinyl');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (34, null, 34, 28.39, 6, 'Aluminum');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (35, null, 35, 11.49, 9, 'Steel');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (36, null, 36, 9.62, 1, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (37, null, 37, 79.33, 8, 'Plastic');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (38, null, 38, 24.03, 3, 'Plexiglass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (39, null, 39, 15.63, 6, 'Brass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (40, null, 40, 57.40, 4, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (41, null, 41, 58.84, 8, 'Aluminum');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (42, null, 42, 30.08, 3, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (43, null, 43, 7.54, 10, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (44, null, 44, 90.49, 12, 'Stone');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (45, null, 45, 93.83, 5, 'Stone');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (46, null, 46, 68.76, 3, 'Plexiglass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (47, null, 47, 7.42, 7, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (48, null, 48, 74.34, 8, 'Granite');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (49, null, 49, 79.97, 1, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (50, null, 50, 35.46, 9, 'Glass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (51, null, 51, 64.28, 3, 'Aluminum');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (52, null, 52, 46.22, 2, 'Glass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (53, null, 53, 76.00, 6, 'Granite');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (54, null, 54, 65.74, 4, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (55, null, 55, 34.92, 3, 'Aluminum');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (56, null, 56, 94.25, 9, 'Steel');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (57, null, 57, 41.61, 3, 'Stone');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (58, null, 58, 8.00,  6, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (59, null, 59, 50.30, 3, 'Glass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (60, null, 60, 52.94, 2, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (61, null, 61, 9.36,  6, 'Plastic');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (62, null, 62, 63.86, 9, 'Plexiglass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (63, null, 63, 28.09, 2, 'Glass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (64, null, 64, 28.59, 1, 'Glass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (65, null, 65, 47.51, 5, 'Glass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (66, null, 66, 25.95, 6, 'Plexiglass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (67, null, 67, 56.92, 1, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (68, null, 68, 5.72, 6, 'Brass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (69, null, 69, 50.64, 4, 'Granite');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (70, null, 70, 44.61, 7, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (71, null, 71, 68.88, 1, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (72, null, 72, 48.36, 6, 'Brass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (73, null, 73, 97.81, 3, 'Aluminum');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (74, null, 74, 29.45, 1, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (75, null, 75, 36.93, 8, 'Brass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (76, null, 76, 26.83, 3, 'Plastic');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (77, null, 77, 12.82, 5, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (78, null, 78, 35.94, 9, 'Plastic');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (79, null, 79, 91.62, 3, 'Glass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (80, null, 80, 34.88, 2, 'Steel');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (81, null, 81, 17.58, 3, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (82, null, 82, 93.35, 6, 'Vinyl');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (83, null, 83, 53.63, 4, 'Brass');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (84, null, 84, 14.98, 5, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (85, null, 85, 67.11, 10, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (86, null, 86, 77.55, 11, 'Steel');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (87, null, 87, 91.82, 7, 'Granite');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (88, null, 88, 35.06, 3, 'Vinyl');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (89, null, 89, 66.22, 9, 'Vinyl');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (90, null, 90, 99.11, 1, 'Plastic');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (91, null, 91, 24.40, 5, 'Granite');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (92, null, 92, 91.64, 2, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (93, null, 93, 84.40, 3, 'Plastic');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (94, null, 94, 68.51, 5, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (95, null, 95, 18.13, 3, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (96, null, 96, 35.34, 5, 'Granite');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (97, null, 97, 23.51, 8, 'Wood');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (98, null, 98, 94.09, 6, 'Rubber');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (99, null, 99, 74.78, 9, 'Plastic');
insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (100, null, 100, 69.91, 10, 'Plastic');
SET SQL_SAFE_UPDATES=0;
delete from cart where pid=103;
update cart set pname ='milk' where quantity<10;
update cart set pname ='cheese' where  quantity>10 && quantity<=20;
update cart set pname ='curd' where quantity>20 && quantity<=30;
update cart set pname ='paneer' where quantity>30 && quantity<=40;
update cart set pname ='ghee' where quantity>40 && quantity<100;

show databases;
use curds;
select * from cart;

select pname,sum(price) 
from cart group by pname;


