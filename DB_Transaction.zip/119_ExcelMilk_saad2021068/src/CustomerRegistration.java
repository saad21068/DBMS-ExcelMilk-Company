import com.sun.security.jgss.GSSUtil;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

class Customer {
    private String username;
    private String password;
    private String email;
    private long phone;
    private String address;
    private int cid;

//    static HashMap<Integer, Cart> order_list=new HashMap<Integer, Cart>();
     static ArrayList<Order> order_list =new ArrayList<>();
     static ArrayList<Payment> payment_list=new ArrayList<>();
    public Customer(String username, String password, String email, long phone, String address,int cid) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.cid=cid;
    }
    static Database db=new Database();
    static ArrayList<Customer> custm=new ArrayList<>();

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getPhone() {
        return phone;
    }

    public void setPhone(long phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    static void sign_up() {
        Scanner scanner=new Scanner(System.in);
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        System.out.print("Enter phone: ");
        long phone = scanner.nextLong();

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter address: ");
        String address = sc.nextLine();

        System.out.print("Enter cid: ");
        int cid = scanner.nextInt();
        boolean flag=false;
        for(int i=0;i<custm.size();i++){
            if(custm.get(i).getCid()==cid){
                flag= true;
                System.out.println("Cid already Taken use another");
            }
        }
        if(!flag){
            // Create a new customer object
            Customer customer = new Customer(username, password, email, phone, address, cid);
            custm.add(customer);
//        System.out.println(custm.get(0).getCid());
            db.createCustomer(customer);
        }
    }
    public static ArrayList<String> log_in(){
        ArrayList<String> arr=new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        String cust_name;
        String password;
        System.out.print("enter name: ");
        cust_name=sc.nextLine();
        System.out.print("enter passoword: ");
        password=sc.nextLine();
        if(Database.getCustomerDetails(cust_name,password)) {
            System.out.println("successfully login");
            arr.add(cust_name);
            arr.add(password);
            return arr;
        }
        return arr;
    }

    static void browsw_product(){
        for(int i=0;i<Cart.cart_list.size();i++){
            System.out.println("product ID: "+Cart.cart_list.get(i).getPid()+"\n" +
                    "Product name: " +Cart.cart_list.get(i).getPname()+"\n" +
                    "Product Price: "+Cart.cart_list.get(i).getPrice()+"\n" +
                    "Product Quantity: "+Cart.cart_list.get(i).getQuantity()+"\n"+
                    "Product DeliveryPeriod: "+Cart.cart_list.get(i).getDeliveryperiod()+"\n"+
                    "Product Specification: "+Cart.cart_list.get(i).getProductdesc());
            System.out.println();
        }
        System.out.println();
//        db.Browse_product();

    }
    static int oid=100;
    public static void add_to_orders(String cname,String pass) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the Product id and the quantity of the product you want to buy: ");
        int pid=sc.nextInt();
        int quantity=sc.nextInt();
        int toalPriceofSingleOrder=db.get_price_of_single_order(pid,quantity,cname,pass);
        int a=0;
//        System.out.println(custm.size());
        for(int i=0;i<custm.size();i++){
            if(custm.get(i).getUsername().equals(cname) && custm.get(i).getPassword().equals(pass)){
                a=i;
            }
        }
//        System.out.println(a);
//        System.out.println(Cart.cart_list.get(0).getPid());
        int b=0;
        for (int i=0;i<Cart.cart_list.size();i++){
            if(Cart.cart_list.get(i).getPid()==pid){
                b=i;
            }
        }
//        System.out.println("qwe");
        oid=oid+1;
        Order order=new Order(oid,Customer.custm.get(a).getAddress(),Customer.custm.get(a).getCid(),pid,toalPriceofSingleOrder,Cart.cart_list.get(b).getDeliveryperiod(),quantity);
//        Customer.order_list.add(order);
//        System.out.println("1234");
//        System.out.println(b);
        if(Cart.cart_list.get(b).getQuantity()==0){
            System.out.println("Product out of stock !! Sorry");
        }else if(quantity>Cart.cart_list.get(b).getQuantity()){
            System.out.println("you can only add maximum "+Cart.cart_list.get(b).getQuantity()+" in you cart ");
        }else{
//            System.out.println("asdfg");
//            System.out.println(custm.get(a).getUsername());
//            Cart.cart_list.get(b).setQuantity(Cart.cart_list.get(b).getQuantity()-quantity);
//            System.out.println("13243");
            db.update_quantity_when_order_adde(Cart.cart_list.get(b).getQuantity()-quantity,pid);
            Cart.cart_list.get(b).setQuantity(Cart.cart_list.get(b).getQuantity()-quantity);
            db.insert_into_order_in_table(order,Cart.cart_list.get(b));
//            custm.get(a).order_list.put(oid++,Cart.cart_list.get(b));
            custm.get(a).order_list.add(order);
        }
        System.out.println("Order Added successfully");
//        System.out.println(custm.get(a).order_list.get(0).getPid());
    }

    public static int view_order_for_customer(String cname,String pass){
        int a=0;
        for(int i=0;i<custm.size();i++){
            if(custm.get(i).getUsername().equals(cname) && custm.get(i).getPassword().equals(pass)){
                a=i;
            }
        }
        System.out.println(custm.get(a).order_list.size());
        for(int i=0;i<custm.get(a).order_list.size();i++){
            System.out.println("OId: "+custm.get(a).order_list.get(i).getOrderId()+"\n" +
                    "Delivery to this Address: "+custm.get(a).getAddress()+"\n" +
                    "Customer Id: "+custm.get(a).getCid()+"\n" +
                    "Product Id you added: "+custm.get(a).order_list.get(i).getProductId());
        }
        int total_Amount=0;
        for(int i=0;i<custm.get(a).order_list.size();i++){
            total_Amount=total_Amount+custm.get(a).order_list.get(i).getTotalPrice();

        }
        System.out.println("Amount Total To be Paid: "+total_Amount);
        return total_Amount;
    }
    public static void empty_order_of_customer(String cname, String pass) {
        int a=0;
        for(int i=0;i<custm.size();i++){
            if(custm.get(i).getUsername().equals(cname) && custm.get(i).getPassword().equals(pass)){
                a=i;
            }
        }
        for(int i=0;i<custm.get(a).order_list.size();i++){
            update_quantity(custm.get(a).order_list.get(i).getProductId(),custm.get(a).order_list.get(i).getQuantity());
        }
        for(int i=0;i<custm.get(a).order_list.size();i++){
            db.DeleteOrderFromOrders(custm.get(a).order_list.get(i));
            custm.get(a).order_list.clear();
        }
        System.out.println(custm.get(a).order_list.size());

    }

    public static void update_quantity(int pid,int quantity){
        for(int i=0;i<Cart.cart_list.size();i++){
            if(Cart.cart_list.get(i).getPid()==pid){
                db.update_quantity_when_order_remove(Cart.cart_list.get(i).getQuantity()+quantity,Cart.cart_list.get(i).getPid());
                Cart.cart_list.get(i).setQuantity(Cart.cart_list.get(i).getQuantity()+quantity);
            }
        }
    }

    static int payid=100;
    static ArrayList<Order> arr=new ArrayList<>();
    static HashMap<Integer, ArrayList<Order>> map=new HashMap<>();

    static int clubed_order_ids=0;
    public static void checkout_orders(String cname, String pass) {
        Scanner sc=new Scanner(System.in)
;        int a=0;
        for(int i=0;i<custm.size();i++){
            if(custm.get(i).getUsername().equals(cname) && custm.get(i).getPassword().equals(pass)){
                a=i;
            }
        }
        int amount_to_pay=view_order_for_customer(cname,pass);
        System.out.print("Do You want to place order: yes or no: ");
        String permission=sc.nextLine();

        if(permission.equals("yes")){
            Date date = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
            String str = formatter.format(date);

            SimpleDateFormat formatter1 = new SimpleDateFormat("HH:mm:ss");
            Date date1= new Date();
            String time2=formatter1.format(date1);

            for(int i=0;i<custm.get(a).order_list.size();i++){
                arr.add(custm.get(a).order_list.get(i));
            }
            clubed_order_ids=clubed_order_ids+1;
            map.put(clubed_order_ids,arr);

            payid=payid+1;
            Payment payment=new Payment(payid,custm.get(a).getCid(),amount_to_pay,str,time2,clubed_order_ids);
            db.insert_paymentDetails_in_payment_table(payment);
            custm.get(a).payment_list.add(payment);
            System.out.print("Do You Want to pay the Total Amount of $"+amount_to_pay+": yes or no: ");
            String answer=sc.nextLine();
            if(answer.equals("yes")){
                System.out.println("Amount paid successfully");
            }
        }
    }
}
class Payment{
    private int payid;
    private int cid;
    private int totalAmount;
    private String paymentDate;
    private String paymentTime;
    private int oid;

    public Payment(int payid, int cid, int totalAmount, String paymentDate, String paymentTime, int oid) {
        this.payid = payid;
        this.cid = cid;
        this.totalAmount = totalAmount;
        this.paymentDate = paymentDate;
        this.paymentTime = paymentTime;
        this.oid = oid;
    }

    public int getPayid() {
        return payid;
    }

    public void setPayid(int payid) {
        this.payid = payid;
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(String paymentTime) {
        this.paymentTime = paymentTime;
    }

    public int getOid() {
        return oid;
    }

    public void setOid(int oid) {
        this.oid = oid;
    }
}


class Farmer {
    private int fid;
    private String username;
    private String email;
    private int phone;
    private String address;
    private int accountNo;
    private String password;

    public Farmer(int fid, String username, String password,String email, int phone, String address, int accountNo) {
        this.fid = fid;
        this.username = username;
        this.password=password;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.accountNo = accountNo;
    }
    static Database db2=new Database();
    static ArrayList<Farmer> farmer=new ArrayList<>();
    public int getFid() {
        return fid;
    }

    public void setFid(int fid) {
        this.fid = fid;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    public static void sign_up(){
        Scanner scanner =new Scanner(System.in);
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        System.out.print("Enter phone: ");
        int phone = scanner.nextInt();

        System.out.print("Enter AccountNo.: ");
        int accountNo = scanner.nextInt();

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter address: ");
        String address = sc.nextLine();

        System.out.print("Enter fid: ");
        int fid = scanner.nextInt();
        System.out.println();
        boolean flag=false;
        for(int i=0;i<farmer.size();i++){
            if(farmer.get(i).getFid()==fid){
                flag= true;
                System.out.println("Fid already Taken use another");
            }
        }
        if(!flag){
            Farmer farmer = new Farmer(fid, username, password, email, phone, address, accountNo);
            Farmer.farmer.add(farmer);
            db2.createFarmer(farmer);
        }

    }


    public static ArrayList<String> log_in(){
        ArrayList<String> arr=new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        String farmer_name;
        String password;
        System.out.print("enter name: ");
        farmer_name=sc.nextLine();
        System.out.print("enter passoword: ");
        password=sc.nextLine();
        if(Database.getFarmerDetails(farmer_name,password)){
            System.out.println("successfully login");
            arr.add(farmer_name);
            arr.add(password);
            return arr;
        }return arr;

    }

    public static void view_orders() {
        for(int i=0;i<Customer.order_list.size();i++){
            System.out.println("OID: "+Customer.order_list.get(i).getOrderId()+"\n" +
                    "pname: "+Customer.order_list.get(i));
        }
    }


}

class Cart{
    private int pid;
    private String pname;
    private int quantity;
    private int price;
    private int deliveryperiod;
    private String productdesc;

    public Cart(int pid, String pname, int quantity, int price, int deliveryperiod, String productdesc) {
        this.pid = pid;
        this.pname = pname;
        this.quantity = quantity;
        this.price = price;
        this.deliveryperiod = deliveryperiod;
        this.productdesc = productdesc;
    }

    static Database db1 = new Database();
    static ArrayList<Cart> cart_list=new ArrayList<>();

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getDeliveryperiod() {
        return deliveryperiod;
    }

    public void setDeliveryperiod(int deliveryperiod) {
        this.deliveryperiod = deliveryperiod;
    }

    public String getProductdesc() {
        return productdesc;
    }

    public void setProductdesc(String productdesc) {
        this.productdesc = productdesc;
    }

    static void add_to_cart() {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Pid: ");
        int pid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Product Name: ");
        String pname = sc.nextLine();

        System.out.print("Enter price: ");
        int price = sc.nextInt();

        System.out.print("Enter Quantity: ");
        int quantity = sc.nextInt();

        System.out.print("Enter Delivery Period: ");
        int delivert_time = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter the product description: ");
        String productdesc = sc.nextLine();

        Cart cart = new Cart(pid, pname, quantity, price, delivert_time, productdesc);
        cart_list.add(cart);
        System.out.println();
        db1.createCart(cart);
    }

    public static void delete_product_cart(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Pid: ");
        int pid = sc.nextInt();
        for(int i=0;i<cart_list.size();i++){
            if(cart_list.get(i).getPid()==pid){
                cart_list.remove(cart_list.get(i));
            }

        }
        db1.DeleteProductFromCart(pid);
    }

    public static void view_cart(){
        for(int i=0;i<cart_list.size();i++){
            System.out.println("product ID: "+cart_list.get(i).getPid()+"\n" +
                    "Product name: " +cart_list.get(i).getPname()+"\n" +
                    "Product Price: "+cart_list.get(i).getPrice()+"\n" +
                    "Product Quantity: "+cart_list.get(i).getQuantity()+"\n"+
                    "Product DeliveryPeriod: "+cart_list.get(i).getDeliveryperiod()+"\n"+
                    "Product Specification: "+cart_list.get(i).getProductdesc());
            System.out.println();
        }
        System.out.println();
    }
}

class Order {
    private int orderId;
    private String deliveryAddress;
    private int customerId;
    private int productId;
    private int totalPrice;
    private  int quantity;

    private int deliveryPerioed;
    public Order(int orderId, String deliveryAddress, int customerId, int productId, int totalPrice,int deliveryPerioed,int quantity) {
        this.orderId = orderId;
        this.deliveryAddress = deliveryAddress;
        this.customerId = customerId;
        this.productId = productId;
        this.totalPrice=totalPrice;
        this.deliveryPerioed=deliveryPerioed;
        this.quantity=quantity;
    }

    // Getters and setters for the attributes
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }
    public int getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getDeliveryPerioed() {
        return deliveryPerioed;
    }

    public void setDeliveryPerioed(int deliveryPerioed) {
        this.deliveryPerioed = deliveryPerioed;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}

public class CustomerRegistration{
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Database db = new Database();
        db.add_all_products_to_cartList();
        db.Add_all_the_customer_to_custm_list();
        boolean exit = false;
        while (!exit){
            System.out.println("1. Customer");
            System.out.println("2. Farmer");
            System.out.println("3. Exit");

            System.out.print("Enter your choice: ");
            int n = scanner.nextInt();
            scanner.nextLine();
            String Cname,Cpass;
            String Fname,Fpass;
            if (n == 1) {
                Scanner sc = new Scanner(System.in);
                boolean Cexit=false;
                while(!Cexit){
                    int choose;
                    System.out.println("""
                                 1) Sign up
                                 2) Log in
                                 3) Back""");
                    choose = sc.nextInt();
                    if (choose == 1) {
                        Customer.sign_up();
                        ArrayList<String> list=new ArrayList<>();
                        System.out.println();
                        System.out.println("Now Login !!");
                        list=Customer.log_in();
                        System.out.println();
                        if(list.isEmpty()){
                            System.out.println("Wrong Credentials!!");
                            Cexit=true;
                        }
                        else {
                            Cname = list.get(0);
                            Cpass = list.get(1);
                            int choose1;
                            boolean exit2 = false;
                            while (!exit2) {
                                System.out.println("Welcome " + Cname + "!!");
                                System.out.println("""
                                        1) browse products
                                        2) add a product to orders
                                        3) view orders
                                        4) empty orders
                                        5) checkout orders
                                        6) back""");
                                choose1 = sc.nextInt();
                                int oid = 0;
                                if (choose1 == 1) {
                                    Customer.browsw_product();
                                } else if (choose1 == 2) {
                                    Customer.add_to_orders(Cname, Cpass);
                                } else if (choose1 == 3) {
                                    Customer.view_order_for_customer(Cname, Cpass);
                                } else if (choose1 == 4) {
                                    Customer.empty_order_of_customer(Cname, Cpass);
                                } else if (choose1 == 5) {
                                    Customer.checkout_orders(Cname,Cpass);
                                } else if (choose1 == 6) {
                                    exit2 = true;
                                }
                            }
                        }
                    } else if (choose == 2) {
                        ArrayList<String> list=new ArrayList<>();
                        list=Customer.log_in();
                        if(list.isEmpty()){
                            System.out.println("Wrong Credentials!!");
                            Cexit=true;
                        }
                        else {
                            Cname = list.get(0);
                            Cpass = list.get(1);
                            System.out.println();
                            int choose1;
                            boolean exit2 = false;
                            while (!exit2) {
                                System.out.println("Welcome " + Cname + "!!");
                                System.out.println();
                                System.out.println("""
                                        1) browse products
                                        2) add a product to orders
                                        3) view orders
                                        4) empty orders
                                        5) checkout orders
                                        6) back""");
                                choose1 = sc.nextInt();
                                if (choose1 == 1) {
                                    Customer.browsw_product();
                                } else if (choose1 == 2) {
                                    Customer.add_to_orders(Cname, Cpass);
                                } else if (choose1 == 3) {
                                    Customer.view_order_for_customer(Cname, Cpass);
                                } else if (choose1 == 4) {
                                    Customer.empty_order_of_customer(Cname, Cpass);
                                } else if (choose1 == 5) {
                                    Customer.checkout_orders(Cname,Cpass);
                                } else if (choose1 == 6) {
                                    exit2 = true;
                                }
                            }
                        }
                    }else if(choose==3){
                        Cexit=true;
                    }
                }
            } else if (n == 2) {
                boolean Fexit = false;
                while (!Fexit) {
                    int choose;
                    System.out.println("""
                            1) Sign up
                            2) Log in
                            3) Back""");
                    choose = scanner.nextInt();
                    scanner.nextLine();
                    if (choose == 1) {
                        Farmer.sign_up();
                        ArrayList<String> list=new ArrayList<>();
                        System.out.println();
                        System.out.println("Now Login !!");
                        list=Farmer.log_in();
                        if(list.isEmpty()){
                            System.out.println("Wrong Credentials!!");
                            Fexit=true;
                        }
                        else{
                            Fname = list.get(0);
                            Fpass = list.get(1);
                            System.out.println();
                            boolean exit1 = false;
                            while (!exit1) {
                                System.out.println("Welcome " + Fname);
                                System.out.println("1) Add to Cart\n" +
                                        "2) Delete From Cart\n" +
                                        "3) View Cart\n" +
                                        "4) view Orders\n" +
                                        "5) Back");
                                int choose3 = scanner.nextInt();
                                if (choose3 == 1) {
                                    Cart.add_to_cart();
                                } else if (choose3 == 2) {
                                    Cart.delete_product_cart();
                                } else if (choose3 == 3) {
                                    Cart.view_cart();
                                } else if (choose3 == 4) {
                                    Farmer.view_orders();
                                } else if (choose3 == 5) {
                                    exit1 = true;
                                }
                            }
                        }
                    } else if (choose == 2) {
                        ArrayList<String> list=new ArrayList<>();
                        list=Farmer.log_in();
                        System.out.println();
                        if(list.isEmpty()){
                            System.out.println("Wrong Credentials!!");
                            Fexit=true;
                        }
                        else {
                            Fname = list.get(0);
                            Fpass = list.get(1);
                            boolean exit1 = false;
                            while (!exit1) {
                                System.out.println("Welcome " + Fname);
                                System.out.println("1) Add to Cart\n" +
                                        "2) Delete From Cart\n" +
                                        "3) View Cart\n" +
                                        "4) View Orders\n" +
                                        "5) Back");
                                int choose3 = scanner.nextInt();
                                if (choose3 == 1) {
                                    Cart.add_to_cart();
                                } else if (choose3 == 2) {
                                    Cart.delete_product_cart();
                                } else if (choose3 == 3) {
                                    Cart.view_cart();
                                } else if (choose3 == 4) {
                                    Farmer.view_orders();
                                } else if (choose3 == 5) {
                                    exit1 = true;
                                }
                            }
                        }

                    } else if (choose == 3) {
                        Fexit = true;
                    }
                }
            }
            else if(n==3){
                exit=true;
                System.out.println("Exit Successfully");
            }else{
                System.out.println("Invalid Choice!! Pls enter the valid choice");
            }
        }


    }
}

