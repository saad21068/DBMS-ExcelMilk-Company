//import java.sql.*;
//
//public class dbms{
//    public static void main(String arg[])
//    {
//        Connection connection = null;
//        try {
//            // below two lines are used for connectivity.
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            connection = DriverManager.getConnection(
//                    "jdbc:mysql://localhost:3306/curds",
//                    "root", "saad");
//
//            Statement statement;
//            statement = connection.createStatement();
//            ResultSet resultSet;
//            resultSet = statement.executeQuery(
//                    "select * from cart");
//            System.out.println(resultSet);
//            int code;
//            String title;
//            while (resultSet.next()) {
//                code = resultSet.getInt("pid");
//                title = resultSet.getString("pname").trim();
//                System.out.println("Code : " + code
//                        + " Title : " + title);
//            }
//            resultSet.close();
//            statement.close();
//            connection.close();
//        }
//        catch (Exception exception) {
//            System.out.println(exception);
//        }
//    } // function ends
//} // class ends
//
//


import java.sql.*;
import java.util.ArrayList;
import java.util.Objects;

public class Database {
    private static Connection connection;

    public Database() {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Create a connection to the database
            String url = "jdbc:mysql://localhost:3306/curds";
            String username = "root";
            String password = "saad";
            connection = DriverManager.getConnection(url, username, password);

            System.out.println("Connected to database");
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error connecting to database: " + e.getMessage());
        }
    }

    public void Add_all_the_customer_to_custm_list(){
        try {
        String sql = "select * from customer";
        PreparedStatement statement = connection.prepareStatement(sql);
        ResultSet rs = null;
        rs = statement.executeQuery(sql);
        // Iterate over the results and print them to the console
        while (rs.next()) {
            int cid = rs.getInt("cid");
            String username = rs.getString("username");
            String email = rs.getString("email");
            String address = rs.getString("address");
            long phone= rs.getLong("contactno");
            String password = rs.getString("password");
            Customer customer=new Customer(username,password,email,(phone),address,cid);
            Customer.custm.add(customer);
        }
    }catch (SQLException e) {
        throw new RuntimeException(e);
    }


    }

    public void createCustomer(Customer customer) {
        try {
            // Prepare the SQL statement
            connection.setAutoCommit(false);
            String sql = "INSERT INTO customer (username, email, cid, address, contactno, password) VALUES (?, ?, ?,?,?,?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, customer.getUsername());
            statement.setString(2, customer.getEmail());
            statement.setInt(3, customer.getCid());
            statement.setString(4, customer.getAddress());
            statement.setLong(5, customer.getPhone());
            statement.setString(6, customer.getPassword());

            // Execute the SQL statement
            statement.executeUpdate();
            connection.commit();
            System.out.println("Customer registerd successfully");
        } catch (SQLException e) {
            System.err.println("Error creating customer: " + e.getMessage());
        }
    }


    public void createFarmer(Farmer farmer) {
        try {
            // Prepare the SQL statement
            String sql = "INSERT INTO farmer (username, email, fid, address, contactno, password, account) VALUES (?,?,?,?,?,?,?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, farmer.getUsername());
            statement.setString(2, farmer.getEmail());
            statement.setInt(3, farmer.getFid());
            statement.setString(4, farmer.getAddress());
            statement.setInt(5, farmer.getPhone());
            statement.setString(6, farmer.getPassword());
            statement.setInt(7, farmer.getAccountNo());
            // Execute the SQL statement
            statement.executeUpdate();
            System.out.println("Farmer Registered successfully");
        } catch (SQLException e) {
            System.err.println("Error creating farmer: " + e.getMessage());
        }
    }

    public static boolean getCustomerDetails(String name, String Password) {
        boolean flag;
        try {
            String sql = "select username,password from customer";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = null;
            rs = statement.executeQuery(sql);
            // Iterate over the results and print them to the console
            flag = false;
            while (rs.next()) {
                String username = rs.getString("username");
                String password = rs.getString("password");
                if (username.equals(name) && password.equals(Password)) {
                    System.out.println("Login successfully");
                    flag = true;
                }
            }
            return flag;

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean getFarmerDetails(String name, String Password) {
        boolean flag;
        try {
            String sql = "select username,password from farmer";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = null;
            rs = statement.executeQuery(sql);
            // Iterate over the results and print them to the console
            flag = false;
            while (rs.next()) {
                String username = rs.getString("username");
                String password = rs.getString("password");
                if (username.equals(name) && password.equals(Password)) {
                    flag = true;
                }
            }
            return flag;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public void createCart(Cart cart) {
        try {
            // Prepare the SQL statement
            String sql = "INSERT INTO cart(pid, pname, quantity, price, deliveryperiod, productdesc) VALUES (?,?,?,?,?,?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, cart.getPid());
            statement.setString(2, cart.getPname());
            statement.setInt(3, cart.getQuantity());
            statement.setInt(4, cart.getPrice());
            statement.setInt(5, cart.getDeliveryperiod());
            statement.setString(6, cart.getProductdesc());

            // Execute the SQL statement
            statement.executeUpdate();
            System.out.println("Product added to the cart successfully");
        } catch (SQLException e) {
            System.err.println("Error creating cart: " + e.getMessage());
        }
    }

    public void DeleteProductFromCart(int pid) {
        try {
            // Prepare the SQL statement
            String sql = "DELETE FROM cart WHERE pid = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, pid);
            // Execute the SQL statement
            statement.executeUpdate();
            System.out.println("product removed successfully");
        } catch (SQLException e) {
            System.err.println("Error" + e.getMessage());
        }
    }

    public void Browse_product() {
        try {
            String sql = "select * from cart";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = null;
            rs = statement.executeQuery(sql);
            // Iterate over the results and print them to the console
            while (rs.next()) {
                int pid = rs.getInt("pid");
                String pname = rs.getString("pname");
                int price = rs.getInt("price");
                int quantity = rs.getInt("quantity");
                int deliveryperioed = rs.getInt("deliveryperiod");
                String productdesc = rs.getString("productdesc");
                System.out.println("product ID: " + pid + "\n" +
                        "Product name: " + pname + "\n" +
                        "Product Price: " + price + "\n" +
                        "Product Quantity: " + quantity + "\n" +
                        "Product DeliveryPeriod: " + deliveryperioed + "\n" +
                        "Product Specification: " + productdesc);
                System.out.println();
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    static int oid=0;

    public int get_price_of_single_order(int pid, int quantity,String cname,String pass) {
        int price = 0;
        try {
            // Prepare the SQL statement
            String sql = "select * from cart";
            PreparedStatement statement = connection.prepareStatement(sql);
//            statement.setInt(1,pid);
            // Execute the SQL statement
//            statement.executeUpdate();
            ResultSet rs = null;
            rs = statement.executeQuery(sql);
            int a=0;
            for(int i=0;i<Customer.custm.size();i++){
                if(Customer.custm.get(i).getUsername().equals(cname) && Customer.custm.get(i).getPassword().equals(pass)){
                    a=i;
                }
            }
            while (rs.next()) {
                int p = rs.getInt("pid");
                if (p == pid) {
                    price = rs.getInt("price")*quantity;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error" + e.getMessage());
        }
        return price;
    }

    public void insert_into_order_in_table(Order order,Cart cart){
        try {
            // Prepare the SQL statement
            String sql = "INSERT INTO orders(oid, deliveryaddress, cid, pid, deliveryperiod) VALUES (?,?,?,?,?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, order.getOrderId());
            statement.setString(2, order.getDeliveryAddress());
            statement.setInt(3, order.getCustomerId());
            statement.setInt(4, order.getProductId());
            statement.setInt(5, order.getDeliveryPerioed());;
            // Execute the SQL statement
            statement.executeUpdate();
            System.out.println("product added to the orders table successfully");
        } catch (SQLException e) {
            System.err.println("Error creating cart: " + e.getMessage());
        }

    }

    public void update_quantity_when_order_remove(int quantity,int pid){
        try{
            String sql="update cart set quantity = ? where pid= ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1,quantity);
            statement.setInt(2,pid);

            statement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void update_quantity_when_order_adde(int quantity,int pid){
        try{
            String sql="update cart set quantity = ? where pid= ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1,quantity);
            statement.setInt(2,pid);

            statement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public void add_all_products_to_cartList() {
        try {
            String sql = "select * from cart";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = null;
            rs = statement.executeQuery(sql);
            // Iterate over the results and print them to the console
            while (rs.next()) {
                int p = rs.getInt("pid");
                String pname = rs.getString("pname");
                int price = rs.getInt("price");
                int quantity = rs.getInt("quantity");
                int deliveryperioed = rs.getInt("deliveryperiod");
                String productdesc = rs.getString("productdesc");
                Cart cart=new Cart(p,pname,quantity,price,deliveryperioed,productdesc);
                Cart.cart_list.add(cart);
            }
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void search_from_cart(int pid){
        try {
            String sql = "select * from cart";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = null;
            rs = statement.executeQuery(sql);
            // Iterate over the results and print them to the console
            while (rs.next()) {
                int p=rs.getInt("pid");
                if(p==pid){

                }
                String pname=rs.getString("pname");
                int price =rs.getInt("price");
                int quantity=rs.getInt("quantity");
                int deliveryperioed=rs.getInt("deliveryperiod");
                String productdesc=rs.getString("productdesc");
                System.out.println("product ID: "+pid+"\n" +
                        "Product name: " +pname+"\n" +
                        "Product Price: "+price+"\n" +
                        "Product Quantity: "+quantity+"\n"+
                        "Product DeliveryPeriod: "+deliveryperioed+"\n"+
                        "Product Specification: "+productdesc);
                System.out.println();
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void DeleteOrderFromOrders(Order order) {
        try {
            // Prepare the SQL statement
            String sql = "DELETE FROM orders WHERE oid = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1,order.getOrderId());
            // Execute the SQL statement
            statement.executeUpdate();
            System.out.println("Order Removed Successfully");
        } catch (SQLException e) {
            System.err.println("Error" + e.getMessage());
        }
    }


    public void insert_paymentDetails_in_payment_table(Payment payment){
        try {
            // Prepare the SQL statement
            String sql = "INSERT INTO payments (payid, cid, totalprice, paymentdate, paymenttime, oid) VALUES (?,?,?,?,?,?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, payment.getPayid());
            statement.setInt(2, payment.getCid());
            statement.setInt(3, payment.getTotalAmount());
            statement.setString(4, payment.getPaymentDate());
            statement.setString(5, payment.getPaymentTime());
            statement.setInt(6,payment.getOid());
            // Execute the SQL statement
            statement.executeUpdate();
            System.out.println("Details added to the payment table successfully");
        } catch (SQLException e) {
            System.err.println("Error insertind details to paymetn table: " + e.getMessage());
        }
    }

}