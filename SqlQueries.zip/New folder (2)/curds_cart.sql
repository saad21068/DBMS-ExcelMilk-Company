-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: curds
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `pid` int DEFAULT NULL,
  `pname` varchar(50) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `deliveryperiod` int DEFAULT NULL,
  `productdesc` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES (1,'cheese',1,'$66.54',1,'Granite'),(2,'cheese',2,'$32.78',2,'Glass'),(3,'cheese',3,'$10.67',3,'Rubber'),(4,'cheese',4,'$61.10',4,'Granite'),(5,'cheese',5,'$17.39',5,'Rubber'),(6,'cheese',6,'$98.36',6,'Stone'),(7,'cheese',7,'$13.31',7,'Aluminum'),(8,'cheese',8,'$25.39',8,'Rubber'),(9,'cheese',9,'$19.06',9,'Plexiglass'),(10,'cheese',10,'$45.01',10,'Aluminum'),(11,'cheese',11,'$8.59',11,'Plastic'),(12,'cheese',12,'$73.37',12,'Vinyl'),(13,'cheese',13,'$45.16',13,'Granite'),(14,'cheese',14,'$89.82',14,'Vinyl'),(15,'cheese',15,'$84.97',15,'Wood'),(16,'cheese',16,'$37.44',16,'Aluminum'),(17,'cheese',17,'$97.35',17,'Wood'),(18,'cheese',18,'$39.16',18,'Granite'),(19,'cheese',19,'$47.31',19,'Granite'),(20,'cheese',20,'$77.92',20,'Aluminum'),(21,'cheese',21,'$14.93',21,'Plastic'),(22,'cheese',22,'$6.55',22,'Steel'),(23,'cheese',23,'$94.50',23,'Vinyl'),(24,'cheese',24,'$16.40',24,'Plexiglass'),(25,'cheese',25,'$66.02',25,'Plexiglass'),(26,'cheese',26,'$28.54',26,'Glass'),(27,'cheese',27,'$77.97',27,'Plexiglass'),(28,'cheese',28,'$66.53',28,'Stone'),(29,'cheese',29,'$7.02',29,'Plexiglass'),(30,'cheese',30,'$94.36',30,'Rubber'),(31,'cheese',31,'$28.56',31,'Vinyl'),(32,'cheese',32,'$71.52',32,'Stone'),(33,'cheese',33,'$74.72',33,'Vinyl'),(34,'cheese',34,'$28.39',34,'Aluminum'),(35,'cheese',35,'$11.49',35,'Steel'),(36,'cheese',36,'$9.62',36,'Wood'),(37,'cheese',37,'$79.33',37,'Plastic'),(38,'cheese',38,'$24.03',38,'Plexiglass'),(39,'cheese',39,'$15.63',39,'Brass'),(40,'cheese',40,'$57.40',40,'Rubber'),(41,'cheese',41,'$58.84',41,'Aluminum'),(42,'cheese',42,'$30.08',42,'Rubber'),(43,'cheese',43,'$7.54',43,'Rubber'),(44,'cheese',44,'$90.49',44,'Stone'),(45,'cheese',45,'$93.83',45,'Stone'),(46,'cheese',46,'$68.76',46,'Plexiglass'),(47,'cheese',47,'$7.42',47,'Rubber'),(48,'cheese',48,'$74.34',48,'Granite'),(49,'cheese',49,'$79.97',49,'Wood'),(50,'cheese',50,'$35.46',50,'Glass'),(51,'cheese',51,'$64.28',51,'Aluminum'),(52,'cheese',52,'$46.22',52,'Glass'),(53,'cheese',53,'$76.00',53,'Granite'),(54,'cheese',54,'$65.74',54,'Wood'),(55,'cheese',55,'$34.92',55,'Aluminum'),(56,'cheese',56,'$94.25',56,'Steel'),(57,'cheese',57,'$41.61',57,'Stone'),(58,'cheese',58,'$8.00',58,'Wood'),(59,'cheese',59,'$50.30',59,'Glass'),(60,'cheese',60,'$52.94',60,'Rubber'),(61,'cheese',61,'$9.36',61,'Plastic'),(62,'cheese',62,'$63.86',62,'Plexiglass'),(63,'cheese',63,'$28.09',63,'Glass'),(64,'cheese',64,'$28.59',64,'Glass'),(65,'cheese',65,'$47.51',65,'Glass'),(66,'cheese',66,'$25.95',66,'Plexiglass'),(67,'cheese',67,'$56.92',67,'Wood'),(68,'cheese',68,'$5.72',68,'Brass'),(69,'cheese',69,'$50.64',69,'Granite'),(70,'cheese',70,'$44.61',70,'Rubber'),(71,'cheese',71,'$68.88',71,'Wood'),(72,'cheese',72,'$48.36',72,'Brass'),(73,'cheese',73,'$97.81',73,'Aluminum'),(74,'cheese',74,'$29.45',74,'Wood'),(75,'cheese',75,'$36.93',75,'Brass'),(76,'cheese',76,'$26.83',76,'Plastic'),(77,'cheese',77,'$12.82',77,'Rubber'),(78,'cheese',78,'$35.94',78,'Plastic'),(79,'cheese',79,'$91.62',79,'Glass'),(80,'curd',80,'$34.88',80,'Steel'),(81,'milk',81,'$17.58',81,'Rubber'),(82,'curd',82,'$93.35',82,'Vinyl'),(83,'milk',83,'$53.63',83,'Brass'),(84,'curd',84,'$14.98',84,'Rubber'),(85,'milk',85,'$67.11',85,'Rubber'),(86,'curd',86,'$77.55',86,'Steel'),(87,'milk',87,'$91.82',87,'Granite'),(88,'curd',88,'$35.06',88,'Vinyl'),(89,'milk',89,'$66.22',89,'Vinyl'),(90,'curd',90,'$99.11',90,'Plastic'),(91,'milk',91,'$24.40',91,'Granite'),(92,'curd',92,'$91.64',92,'Rubber'),(93,'milk',93,'$84.40',93,'Plastic'),(94,'curd',94,'$68.51',94,'Wood'),(95,'milk',95,'$18.13',95,'Wood'),(96,'curd',96,'$35.34',96,'Granite'),(97,'milk',97,'$23.51',97,'Wood'),(98,'curd',98,'$94.09',98,'Rubber'),(99,'milk',99,'$74.78',99,'Plastic'),(100,'curd',100,'$69.91',100,'Plastic');
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 21:38:51
