-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: curds
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `oid` int DEFAULT NULL,
  `deliveryaddress` varchar(50) DEFAULT NULL,
  `cid` varchar(50) DEFAULT NULL,
  `pid` varchar(50) DEFAULT NULL,
  `deliveryperiod` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'Melissa','43','97','Female'),(2,'Frederique','56','83','Female'),(3,'Reinwald','63','88','Male'),(4,'Javier','35','34','Male'),(5,'Georgianne','13','11','Female'),(6,'Leonhard','70','49','Male'),(7,'Berk','25','71','Male'),(8,'Dene','57','84','Male'),(9,'Stu','69','56','Male'),(10,'Kirsteni','9','8','Female'),(11,'Lana','95','94','Female'),(12,'Hernando','33','62','Male'),(13,'Brynne','84','99','Female'),(14,'Lacy','66','26','Female'),(15,'Bondy','4','81','Male'),(16,'Gnni','47','19','Female'),(17,'Ingmar','18','40','Male'),(18,'Wolf','52','96','Male'),(19,'Trever','97','74','Male'),(20,'Augusto','94','86','10'),(21,'Annabelle','7','63','Female'),(22,'Hamid','10','1','Male'),(23,'Simon','53','82','Male'),(24,'Dulcea','40','29','Female'),(25,'Sinclair','67','48','Male'),(26,'Chilton','91','9','Male'),(27,'Erika','62','44','Female'),(28,'Gabrielle','38','6','Female'),(29,'Rossy','100','4','Male'),(30,'Waiter','19','59','Male'),(31,'Che','93','91','Male'),(32,'Denis','26','60','Male'),(33,'Kendra','48','22','Genderfluid'),(34,'Emelyne','87','51','Female'),(35,'Lorne','76','75','Male'),(36,'Adah','27','73','Female'),(37,'Julie','14','90','Male'),(38,'Christos','29','35','Male'),(39,'Milt','1','23','Bigender'),(40,'Finn','20','2','Male'),(41,'Alford','90','27','Male'),(42,'Vito','11','98','Agender'),(43,'Charlotte','41','38','Female'),(44,'Krysta','39','92','Female'),(45,'Jehu','31','10','Male'),(46,'Gaby','82','66','Female'),(47,'Willie','54','21','Male'),(48,'Harmon','36','87','Genderfluid'),(49,'Patrice','59','70','Male'),(50,'Westbrooke','2','39','Male'),(51,'Kaylil','72','80','Bigender'),(52,'Mina','77','17','Female'),(53,'Kris','32','61','Male'),(54,'Veda','8','43','Female'),(55,'Rabi','96','30','Male'),(56,'Henrietta','15','42','Female'),(57,'Isidore','37','65','Male'),(58,'Barbee','28','14','Female'),(59,'Dickie','42','53','Polygender'),(60,'Noam','21','67','Male'),(61,'Hastings','12','36','Male'),(62,'Malissia','60','77','Female'),(63,'Eda','92','85','Female'),(64,'Andrei','16','93','Female'),(65,'Culley','86','3','Male'),(66,'Freedman','85','16','Male'),(67,'Burk','5','28','Male'),(68,'Shirl','46','50','Female'),(69,'Inessa','64','18','Female'),(70,'Foss','45','24','Male'),(71,'Tomaso','81','100','Male'),(72,'Mauricio','50','31','Male'),(73,'Bridgette','98','7','Female'),(74,'Meghann','30','79','Female'),(75,'Charmine','75','25','Genderfluid'),(76,'Silvanus','55','95','Male'),(77,'Parsifal','6','89','Male'),(78,'Con','78','76','Male'),(79,'Josefa','17','15','Female'),(80,'Lari','83','46','Female'),(81,'Bartholomew','23','64','Male'),(82,'Shanna','58','47','Female'),(83,'Nelli','24','78','Female'),(84,'Edyth','99','45','Female'),(85,'Elissa','61','58','Female'),(86,'Reinhard','49','41','Male'),(87,'Cordy','68','52','Male'),(88,'Samara','34','32','Female'),(89,'Ximenez','80','13','Male'),(90,'Lorna','65','33','Female'),(91,'Octavius','89','57','Male'),(92,'Reginald','73','72','Male'),(93,'Barris','44','5','Male'),(94,'Dniren','22','55','Female'),(95,'Ardisj','74','69','Female'),(96,'Gawen','79','54','Male'),(97,'Maddy','71','12','Female'),(98,'Mirabel','51','70','Female'),(99,'Fransisco','79','98','Male'),(100,'Jemima','4','100','Female');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 21:38:51
