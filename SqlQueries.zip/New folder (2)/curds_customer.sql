-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: curds
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `cid` int DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `contactno` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('gdibble0','hbarabisch0@discovery.com',1,'18th Floor','3476177640','V279OPiz'),('dtrime1','bmccolgan1@irs.gov',2,'10th Floor','4116297950','38JcEE3m'),('btuma3','byeldham3@hud.gov',4,'Room 535','8562306106','yxzQuG'),('flghan4','eyaxley4@flickr.com',5,'Apt 1788','8336121773','kxtp9NYB6'),('dluter5','rtinson5@dot.gov',6,'PO Box 11990','1571769033','makKnN'),('cbromby6','haspinal6@comsenz.com',7,'Suite 71','6815334990','f2yzZByi'),('aohenery7','sdomenge7@vistaprint.com',8,'20th Floor','4437797351','DbUxplR0b'),('rmcdunlevy8','cgreger8@slideshare.net',9,'Room 269','8128545325','wWOFksL'),('lkisbey9','cstadding9@ft.com',10,'Room 1069','8397988734','xQ2KR09Y'),('btruelocka','ekerricha@businessinsider.com',11,'Suite 56','2819816687','L0qaiJwxEuB'),('tdenneb','abenningb@cam.ac.uk',12,'Room 67','7697858236','se8cOI4Q'),('cferonetc','dcrowderc@miibeian.gov.cn',13,'Apt 118','5796880662','DD68QMJyMci'),('lbressond','nstimpsond@virginia.edu',14,'18th Floor','2607506294','eGt9IwlWZ4fb'),('mshilvocke','mbrunte@independent.co.uk',15,'Apt 1006','5428836241','kCRhZfS3AAkP'),('mprestnerf','mdemaidf@china.com.cn',16,'Room 1268','5811092342','dAv4C7'),('whessentalerg','kdrinkwaterg@shareasale.com',17,'PO Box 20802','5291086867','MLBKo69ONN5'),('tmaudsleyh','miacivellih@dyndns.org',18,'Apt 1511','2117021416','HNgbmmdE'),('cpringi','jfurnivali@cnet.com',19,'11th Floor','1129235787','iyIQyC7wCM'),('bgallyj','klusherj@last.fm',20,'10th Floor','3582917190','QWb9Qpt'),('rhearmonk','sgrigolashvillk@fotki.com',21,'7th Floor','4411751248','R6CGmq'),('hpaurl','cswindinl@ucoz.com',22,'PO Box 82962','5372660646','1Kyf5hwpTUlm'),('cblomefieldm','bgowanm@abc.net.au',23,'PO Box 38928','5365222444','exX8KPHN'),('llardgen','mburnessn@aol.com',24,'PO Box 73677','7766182574','ahVXVOnRgnm'),('dmablesono','edelatremoilleo@unc.edu',25,'Room 1080','9345180895','r0VTr7rGf3e'),('jhuckp','gebertzp@mashable.com',26,'Suite 83','2123369981','EdHw8hywI'),('kmoranq','astellmanq@ameblo.jp',27,'Apt 1419','1566315776','pmFjESNrfnE'),('ymcileenr','vgippesr@geocities.jp',28,'Apt 770','2344977796','1vVOFWTKFUl'),('mrudds','dorhrts@printfriendly.com',29,'Suite 53','7718549866','EoNBxky681Cd'),('hdellortot','gpolkinghornet@dropbox.com',30,'Apt 771','5241963370','rh3RH7GN'),('dmerrikinu','pspillardu@princeton.edu',31,'Room 609','4419193241','s4M9XQ86JUj'),('tsperlingv','fbowllerv@networkadvertising.org',32,'Apt 1322','3606595773','0ZZkyzv9klC9'),('abuxcyw','mmuntw@cbc.ca',33,'PO Box 97759','1336950029','b7C6VNmjmXWS'),('mmellowsx','sdebenedictisx@cdc.gov',34,'Apt 1694','6504111084','y6ftKcL9'),('cgawthorpey','aedgecumbey@hc360.com',35,'Suite 58','6527779464','cD61HXmsNU9e'),('nrowlandz','walloisiz@istockphoto.com',36,'Apt 1389','1396171706','NXVpL7b'),('vbrennan10','dleall10@parallels.com',37,'PO Box 9732','3854863703','NBXEU6g'),('hodriscoll11','wmccurlye11@theguardian.com',38,'Room 390','6614343452','ME0zJb9nUTy'),('ageorgiev12','rhance12@businessinsider.com',39,'Room 564','1173306682','AYVIOmylQ'),('bhillan13','edevall13@networksolutions.com',40,'PO Box 14763','6243493034','Movu3P3d4KY'),('clardner14','wfarnon14@edublogs.org',41,'Room 711','7727038959','iPd8KKc7boIf'),('kdilucia15','bgowthrop15@furl.net',42,'Apt 231','1918613859','qaHqn9FX57nG'),('lnelsey16','arenad16@xinhuanet.com',43,'20th Floor','4391870892','3wGl6b'),('beymer17','cbrouard17@gnu.org',44,'PO Box 4453','4285305617','aOWVXri1hrLA'),('onewvell18','nbrodeur18@columbia.edu',45,'Room 368','6213107043','DIGRsdn2EY'),('ccusack19','glidgey19@typepad.com',46,'Suite 81','3305018382','B6k3RP4xr7s'),('hmeasham1a','civanuschka1a@msu.edu',47,'Apt 1195','6829101248','H42jObETVJa'),('mrighy1b','jnequest1b@delicious.com',48,'4th Floor','6491964241','c4Rmqv6p'),('lbeney1c','mmowen1c@umn.edu',49,'Room 485','9836867132','Vl2D85Lxy'),('aleif1d','fbosanko1d@cyberchimps.com',50,'Suite 64','4222725498','XWRIvgTJoX1'),('bcotes1e','pcampanelle1e@oracle.com',51,'1st Floor','7299476920','xrpm4jkR1f'),('hselland1f','wphilippard1f@businessweek.com',52,'Room 1966','4583335648','VGvD9X1i'),('bbollum1g','pepiscopi1g@blogtalkradio.com',53,'3rd Floor','6734248038','DQo4jRGxyyG'),('cpallaske1h','clubeck1h@weebly.com',54,'PO Box 6580','4938183306','qbH5OE'),('rpinniger1i','mquibell1i@tmall.com',55,'PO Box 31312','1088276674','LmigGixTBdBt'),('kfellona1j','wsiggs1j@msu.edu',56,'Suite 71','6203819291','KlyyYP1'),('emenure1k','rfashion1k@about.me',57,'Suite 43','5748027728','cOYKLPM'),('kburgis1l','jburgon1l@joomla.org',58,'Suite 19','5998123462','hgV2js9Ft'),('hmicco1m','steliga1m@themeforest.net',59,'Room 975','7976837876','wU82fZ'),('hsemechik1n','cbeneze1n@intel.com',60,'PO Box 21200','8824910480','oVJEYfFg'),('ubriar1o','gsolon1o@nydailynews.com',61,'Suite 75','6784971257','JgBOIEw4HJu'),('scuffin1p','ktacker1p@yahoo.com',62,'Suite 59','5207257378','sT9bdMn'),('nnendick1q','mcloute1q@washingtonpost.com',63,'PO Box 42003','4672905608','zYjzpqO'),('mbell1r','lgwyn1r@parallels.com',64,'PO Box 1118','7814137138','m9CMdLblJ9qn'),('zjendrach1s','crobel1s@ucoz.com',65,'Apt 1570','1325307702','A0IdPyCGb'),('bissit1t','ecortese1t@cbc.ca',66,'13th Floor','3188160902','LSP9elFAZL8'),('hverrier1u','eberthot1u@parallels.com',67,'Room 1389','9492002235','lb3tUXbk7X'),('rtulk1v','sfoch1v@surveymonkey.com',68,'Suite 49','9364317306','Skk670mRiOd'),('akinig1w','fkid1w@webnode.com',69,'9th Floor','5386347210','Jhi0HckkxyG'),('aferriman1x','tredding1x@reuters.com',70,'Suite 68','1727048598','UsD6yQSbrR0'),('etravers1y','jgoley1y@list-manage.com',71,'PO Box 98491','9581060897','WsNPVW'),('gheakins1z','bdirkin1z@webmd.com',72,'PO Box 6231','9946720893','Rik8WjEUD'),('leyres20','jold20@sphinn.com',73,'Apt 754','9181750147','ZNizFJBpE'),('lyearne21','abuckerfield21@mit.edu',74,'Apt 653','4258436602','HlNpFi'),('alaroux22','sacomb22@tripadvisor.com',75,'Room 245','3044030934','AbvbGHY0Oib5'),('gburgot23','ddavenell23@google.cn',76,'3rd Floor','5189095041','ZGIPsc'),('smcmonies24','ctrass24@noaa.gov',77,'Apt 430','6593077395','oUEC40U'),('lstarbuck25','ljuris25@clickbank.net',78,'PO Box 63348','2411150614','WKnNw8G'),('cgogerty26','mmicklewright26@shop-pro.jp',79,'Suite 28','2231967846','gt766Vc19R'),('lbraidley27','mbraiden27@sbwire.com',80,'Apt 1640','8537294918','wrl7tkUX'),('echallicum28','csearchwell28@umn.edu',81,'14th Floor','9948570177','6v5w9O1FChF5'),('rmulvaney29','fclunan29@google.com.hk',82,'Room 1587','2532815993','0sHX4wCfmLn'),('acattemull2a','wjanuszewicz2a@cyberchimps.com',83,'Apt 774','4883645394','ZFmn8LV'),('kgreatland2b','bmorrall2b@java.com',84,'Room 936','1782694827','MtKck9cQ'),('lcocklie2c','ssmees2c@blinklist.com',85,'18th Floor','9954587141','4QO3mdp'),('escoon2d','dscuse2d@soundcloud.com',86,'Suite 61','4105372042','yxtEgdjj'),('jivancevic2e','ltomley2e@craigslist.org',87,'1st Floor','7234110358','fjYjacEYyuTm'),('fsloegrave2g','fmanicomb2g@blogger.com',89,'Apt 1580','1831633542','xf4IFsPm'),('atrower2h','slarsen2h@narod.ru',90,'20th Floor','5418089336','icbsXTyeEp'),('bschule2i','tketts2i@miibeian.gov.cn',91,'Apt 639','5876125419','q9xwTbuf1w3p'),('ewarbeys2j','bkilgrew2j@istockphoto.com',92,'Apt 1993','2934914808','uRjmi1cP'),('gbrisco2k','genticknap2k@mit.edu',93,'Apt 1552','9495099907','ENVArz9'),('mmccloughlin2l','dbraker2l@smh.com.au',94,'2nd Floor','4074629202','PrjX6zr'),('dhosten2m','araulin2m@sciencedaily.com',95,'Room 1397','8343099787','OEFERb8YT1a'),('kmollnar2n','sdutton2n@comsenz.com',96,'Room 309','1588703749','xj5YYM'),('sfilipychev2o','lhousley2o@mtv.com',97,'18th Floor','4512625830','WTx9TryaN9h'),('eosgood2p','fmahody2p@paginegialle.it',98,'PO Box 75529','3874305104','Fq5AlxXQ5P0f'),('dgrimes2q','gglanert2q@wix.com',99,'8th Floor','7173527714','ZlVKtAlBSkE'),('trichens2r','cscamerdine2r@lulu.com',100,'17th Floor','4233976129','7QigIht');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 21:38:51
