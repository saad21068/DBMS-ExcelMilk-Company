-- use curds;
-- SELECT o.oid, o.deliveryaddress, o.cid, c.pid, c.pname, c.quantity, c.price, c.deliveryperiod, c.productdesc
--  FROM orders o
-- JOIN cart c
--  ON o.pid = c.pid;

-- SELECT cart.pid, pname, COUNT(*) as Num_Orders
--  FROM orders
-- JOIN cart ON orders.pid = cart.pid
-- GROUP BY cart.pid,cart.pname;

-- SELECT c.pid, c.pname, max(c.quantity) AS Total_Quantity_Sold
--  FROM orders o
--    JOIN cart c
--   ON o.pid = c.pid
--   GROUP BY c.pid,c.pname
--   ORDER BY Total_Quantity_Sold DESC
--  LIMIT 5;

-- DELETE FROM customer WHERE cid NOT IN (SELECT DISTINCT cid FROM orders);
-- SET SQL_SAFE_UPDATES=0;

-- SELECT totalprice AS TotalRevenue
--  FROM payments
--  WHERE oid IN (
--     SELECT oid FROM orders WHERE pid = 26 AND deliveryperiod >= 10
--  );

-- SELECT pname, price, deliveryperiod
-- FROM cart
--  WHERE pid = 22 
--  ORDER BY `Price` DESC;


--  SELECT customer.username, customer.email, customer.contactno
--  FROM customer
--  JOIN orders ON customer.cid = orders.cid
--  JOIN cart ON orders.pid = cart.pid
--  WHERE cart.pname = 'cheese';

-- SELECT * FROM customer 
-- WHERE cid NOT IN (SELECT cid FROM orders WHERE pid = 12);

-- SELECT *
-- FROM payments join orders
-- on payments.oid = orders.oid;

-- UPDATE orders
-- SET deliveryperiod = '10'
-- WHERE oid = '20';




