-- OLAP QUERIS
-- 1)) 

SELECT pname, SUM(price) 
FROM cart 
GROUP BY pname WITH ROLLUP;
-- 2)) 

SELECT pname,productdesc 
FROM cart 
GROUP BY pname,productdesc WITH ROLLUP;

-- 3))
select avg(deliveryperiod)
from orders group by deliveryperiod with rollup;

-- 4)) 
select *from orders;
select avg(totalprice)
from payments group by totalprice with rollup;