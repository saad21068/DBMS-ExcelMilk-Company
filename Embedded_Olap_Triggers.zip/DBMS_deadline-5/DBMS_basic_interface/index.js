var con=require('./next');
var express= require('express');
var app=express();

var bodyParser=require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
 app.set('view engine','ejs');
app.get('/',function(req,res){

res.sendFile(__dirname+'/register.html')
});

app.post('/',function(req,res){
//console.log(req.body);
var name=req.body.name;
  var email=req.body.email;
  var mno=req.body.mno;
  var add=req.body.address;
   var pass=req.body.pass;
   var c=100;
con.connect(function(error){
//if(error) throw error;
c+=1;
var sql="INSERT INTO customer(username, email, cid, address, contactno, password) VALUES('"+name+"','"+email+"','"+c+"','"+add+"','"+mno+"','"+pass+"')";

con.query(sql,function(error,result){
if(error) throw error;
 //res.send(' sucessfully registered by customer '+result.insertId);
 res.redirect('/customer');
});

});

});

app.get ('/customer',function(req,res){
con.connect(function(error){
  if(error) console.log(error);

  var sql="select * from customer";

  con.query(sql,function(error,result){
if(error) throw console.log(error);
res.render(__dirname+"/customer",{customer:result});
//console.log(result);

});


  });
  });








app.get('/carts',function(req,res){
res.sendFile(__dirname+'/carts.html')
});
app.post('/carts',function(req,res){

  //if(error) throw error;
var name=req.body.name;
  var price=req.body.price;
  var qno=req.body.qno;
  var delivery=req.body.deliveryperiod;
   var desc=req.body.desc;
   var c=100;
con.connect(function(error){
//  if(error) throw error;
c+=1;
var sql="INSERT INTO cart (pid, pname, quantity, price, deliveryperiod, productdesc) VALUES ('"+c+"','"+name+"','"+qno+"','"+price+"','"+delivery+"','"+desc+"')";

con.query(sql,function(error,result){
if(error) console.log(error);

 res.send(' sucessfully added to cart ');
 //res.redirect(' /carttable');

});


});

});

app.get ('/carttable',function(req,res){
con.connect(function(error){
  if(error)  console.log(error);

  var sql="select * from cart";

  con.query(sql,function(error,result){
if(error)  console.log(error);
res.render(__dirname+"/carttable",{carttable:result});
//console.log(result);

});


  });
  });

app.listen(7000)


