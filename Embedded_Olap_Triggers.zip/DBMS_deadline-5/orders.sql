
create table orders (
	oid INT,
	deliveryaddress VARCHAR(50),
	cid VARCHAR(50),
	pid VARCHAR(50),
	deliveryperiod VARCHAR(50)
);
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (1, 'Melissa', '43', '97', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (2, 'Frederique', '56', '83', '1 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (3, 'Reinwald', '63', '88', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (4, 'Javier', '35', '34', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (5, 'Georgianne', '13', '11', '4 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (6, 'Leonhard', '70', '49', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (7, 'Berk', '25', '71', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (8, 'Dene', '57', '84', '1 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (9, 'Stu', '69', '56', '5 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (10, 'Kirsteni', '9', '8', '4 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (11, 'Lana', '95', '94', '1 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (12, 'Hernando', '33', '62', '5 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (13, 'Brynne', '84', '99', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (14, 'Lacy', '66', '26', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (15, 'Bondy', '4', '81', '5 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (16, 'Gnni', '47', '19', '5 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (17, 'Ingmar', '18', '40', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (18, 'Wolf', '52', '96', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (19, 'Trever', '97', '74', '1 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (20, 'Augusto', '94', '86', '9 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (21, 'Annabelle', '7', '63', '5 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (22, 'Hamid', '10', '1', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (23, 'Simon', '53', '82', '9 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (24, 'Dulcea', '40', '29', '10 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (25, 'Sinclair', '67', '48', '4 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (26, 'Chilton', '91', '9', '1 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (27, 'Erika', '62', '44', '6 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (28, 'Gabrielle', '38', '6', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (29, 'Rossy', '100', '4', '7 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (30, 'Waiter', '19', '59', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (31, 'Che', '93', '91', '9 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (32, 'Denis', '26', '60', '1 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (33, 'Kendra', '48', '22', '4 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (34, 'Emelyne', '87', '51', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (35, 'Lorne', '76', '75', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (36, 'Adah', '27', '73', '4 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (37, 'Julie', '14', '90', '6 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (38, 'Christos', '29', '35', '7 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (39, 'Milt', '1', '23', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (40, 'Finn', '20', '2', '9 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (41, 'Alford', '90', '27', '4 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (42, 'Vito', '11', '98', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (43, 'Charlotte', '41', '38', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (44, 'Krysta', '39', '92', '7 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (45, 'Jehu', '31', '10', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (46, 'Gaby', '82', '66', '9 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (47, 'Willie', '54', '21', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (48, 'Harmon', '36', '87', '7 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (49, 'Patrice', '59', '70', '1 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (50, 'Westbrooke', '2', '39', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (51, 'Kaylil', '72', '80', '6 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (52, 'Mina', '77', '17', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (53, 'Kris', '32', '61', '4 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (54, 'Veda', '8', '43', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (55, 'Rabi', '96', '30', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (56, 'Henrietta', '15', '42', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (57, 'Isidore', '37', '65', '5 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (58, 'Barbee', '28', '14', '7 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (59, 'Dickie', '42', '53', '7 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (60, 'Noam', '21', '67', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (61, 'Hastings', '12', '36', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (62, 'Malissia', '60', '77', '9 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (63, 'Eda', '92', '85', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (64, 'Andrei', '16', '93', '9 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (65, 'Culley', '86', '3', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (66, 'Freedman', '85', '16', '9 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (67, 'Burk', '5', '28', '10 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (68, 'Shirl', '46', '50', '1 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (69, 'Inessa', '64', '18', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (70, 'Foss', '45', '24', '4 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (71, 'Tomaso', '81', '100', '6 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (72, 'Mauricio', '50', '31', '7 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (73, 'Bridgette', '98', '7', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (74, 'Meghann', '30', '79', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (75, 'Charmine', '75', '25', '6 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (76, 'Silvanus', '55', '95', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (77, 'Parsifal', '6', '89', '6 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (78, 'Con', '78', '76', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (79, 'Josefa', '17', '15', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (80, 'Lari', '83', '46', '5 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (81, 'Bartholomew', '23', '64', '1 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (82, 'Shanna', '58', '47', '6 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (83, 'Nelli', '24', '78', '10 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (84, 'Edyth', '99', '45', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (85, 'Elissa', '61', '58', '7 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (86, 'Reinhard', '49', '41', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (87, 'Cordy', '68', '52', '4 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (88, 'Samara', '34', '32', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (89, 'Ximenez', '80', '13', '4 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (90, 'Lorna', '65', '33', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (91, 'Octavius', '89', '57', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (92, 'Reginald', '73', '72', '1 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (93, 'Barris', '44', '5', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (94, 'Dniren', '22', '55', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (95, 'Ardisj', '74', '69', '3 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (96, 'Gawen', '79', '54', '2 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (97, 'Maddy', '71', '12', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (98, 'Mirabel', '51', '70', '8 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (99, 'Fransisco', '79', '98', '10 days');
insert into orders (oid, deliveryaddress, cid, pid, deliveryperiod) values (100, 'Jemima', '4', '100', '4 days');

 SELECT o.oid, o.deliveryaddress, o.cid, c.pid, c.pname, c.quantity, c.price, c.deliveryperiod, c.productdesc
 FROM orders o
JOIN cart c
 ON o.pid = c.pid;
 
 SELECT c.pid, c.pname, c.price ,c.quantity,(price*quantity) AS Total_Revenue
FROM orders o
JOIN cart c
ON o.pid = c.pid;

show tables;

SELECT o.oid, o.deliveryaddress, o.cid, c.pid, c.pname, c.quantity, c.price, c.deliveryperiod, c.productdesc
 FROM orders o
JOIN cart c
 ON o.pid = c.pid;
 
 select*from orders;
 
 SET SQL_SAFE_UPDATES=0;
delete from orders where oid=101;
delete from orders where oid=102;


select avg(deliveryperiod)
from orders group by deliveryperiod with rollup;