
import MySQLdb

conn = MySQLdb.connect(user='root', password='saad', host='localhost', database='curd')
print(conn)
if conn:
    print("datbase connected")
mycursor = conn.cursor()
n = int(input("enter the command number you want to execute: "))
if n == 1:
    mycursor.execute("SELECT o.orderId, o.deliveryAddress, o.customerID,c.productName, c.quantity, c.price, "
                     "c.deliveryPeriod, c.productDescription FROM orders o JOIN cart c on o.productID=o.ProductId")
elif n == 2:
    mycursor.execute("SELECT * FROM customer WHERE ContactNo>3992077732")
elif n == 3:
    mycursor.execute("select cart.productName,cart.quantity,cart.price from cart")
row = mycursor.fetchone()
while row is not None:
    print(row)
    row = mycursor.fetchone()
