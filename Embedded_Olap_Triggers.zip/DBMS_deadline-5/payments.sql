
create table payments (
	payid INT,
	cid VARCHAR(50),
	totalprice decimal(10,2),
	paymentdate  VARCHAR(50),
	paymenttime VARCHAR(50),
	oid INT
);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (1, '1', 72.03, '6/27/2022', '7:48 PM', 1);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (2, '14', 15.78, '3/21/2022', '3:15 AM', 2);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (3, '58', 31.73, '6/11/2022', '12:25 PM', 3);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (4, '97', 44.13, '6/11/2022', '10:18 PM', 4);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (5, '8', 27.83, '4/6/2022', '4:02 PM', 5);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (6, '65', 14.38, '6/10/2022', '1:45 PM', 6);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (7, '36', 72.92, '8/22/2022', '10:04 PM', 7);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (8, '51', 29.43, '3/23/2022', '6:43 PM', 8);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (9, '9', 39.03, '5/14/2022', '6:04 PM', 9);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (10, '83', 39.82, '8/25/2022', '12:44 PM', 10);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (11, '33', 44.53, '10/13/2022', '11:37 PM', 11);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (12, '22', 5.03, '4/2/2022', '3:52 PM', 12);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (13, '85', 33.89, '1/5/2023', '3:24 AM', 13);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (14, '37', 84.37, '11/18/2022', '12:03 AM', 14);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (15, '80', 74.64, '1/22/2023', '10:26 PM', 15);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (16, '27', 87.82, '4/19/2022', '6:52 PM', 16);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (17, '70', 34.80, '12/25/2022', '8:54 PM', 17);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (18, '56', 13.99, '7/13/2022', '9:14 AM', 18);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (19, '29', 17.71, '3/31/2022', '11:54 AM', 19);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (20, '93', 18.19, '7/9/2022', '3:55 AM', 20);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (21, '48', 99.62, '6/1/2022', '3:07 PM', 21);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (22, '23', 99.44, '10/20/2022', '7:08 AM', 22);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (23, '11', 31.97, '9/18/2022', '2:16 PM', 23);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (24, '81', 85.37, '9/17/2022', '10:48 PM', 24);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (25, '94', 32.87, '4/13/2022', '3:04 AM', 25);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (26, '98', 48.23, '8/20/2022', '5:02 AM', 26);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (27, '78', 45.14, '1/5/2023', '3:49 PM', 27);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (28, '39', 66.46, '7/10/2022', '5:04 AM', 28);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (29, '12', 39.27, '5/8/2022', '5:46 AM', 29);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (30, '31', 32.48, '8/14/2022', '6:21 AM', 30);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (31, '5', 12.63, '10/30/2022', '4:46 PM', 31);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (32, '41', 54.68, '7/4/2022', '10:09 PM', 32);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (33, '87', 43.63, '5/4/2022', '1:43 AM', 33);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (34, '99', 49.02, '8/30/2022', '9:17 PM', 34);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (35, '88', 37.83, '7/11/2022', '1:49 AM', 35);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (36, '100', 48.76, '4/26/2022', '4:31 AM', 36);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (37, '55', 50.38, '6/28/2022', '2:19 PM', 37);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (38, '21', 97.83, '9/14/2022', '7:09 PM', 38);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (39, '82', 61.32, '6/17/2022', '5:24 PM', 39);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (40, '42', 95.96, '6/5/2022', '9:14 AM', 40);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (41, '89', 95.47, '3/8/2022', '1:41 PM', 41);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (42, '84', 79.92, '10/15/2022', '5:15 AM', 42);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (43, '43', 62.95, '10/18/2022', '12:44 PM', 43);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (44, '57', 29.30, '5/29/2022', '5:21 PM', 44);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (45, '17', 55.95, '12/30/2022', '1:05 PM', 45);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (46, '92', 56.63, '12/23/2022', '12:01 AM', 46);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (47, '28', 19.93, '11/2/2022', '9:49 AM', 47);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (48, '18', 46.54, '9/5/2022', '6:43 AM', 48);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (49, '72', 52.60, '1/12/2023', '10:34 AM', 49);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (50, '71', 97.04, '7/12/2022', '10:51 AM', 50);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (51, '4', 80.98, '4/30/2022', '8:41 AM', 51);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (52, '77', 36.13, '8/10/2022', '3:52 AM', 52);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (53, '96', 68.38, '5/14/2022', '1:05 PM', 53);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (54, '90', 16.58, '6/25/2022', '2:42 PM', 54);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (55, '63', 94.98, '5/25/2022', '11:12 AM', 55);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (56, '2', 64.41, '3/24/2022', '6:44 PM', 56);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (57, '16', 76.89, '10/25/2022', '4:43 PM', 57);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (58, '30', 93.24, '11/18/2022', '9:35 PM', 58);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (59, '24', 77.52, '8/31/2022', '9:24 AM', 59);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (60, '46', 36.83, '7/28/2022', '2:55 AM', 60);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (61, '47', 44.84, '12/8/2022', '1:56 AM', 61);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (62, '13', 92.29, '2/15/2023', '1:16 PM', 62);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (63, '91', 5.38, '4/18/2022', '4:43 AM', 63);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (64, '32', 20.35, '8/30/2022', '7:57 AM', 64);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (65, '54', 23.67, '10/27/2022', '9:02 PM', 65);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (66, '19', 61.97, '2/28/2022', '11:46 PM', 66);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (67, '35', 89.18, '5/7/2022', '6:38 PM', 67);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (68, '52', 34.38, '3/1/2022', '9:59 PM', 68);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (69, '62', 51.25, '9/23/2022', '12:22 PM', 69);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (70, '45', 70.13, '1/27/2023', '11:42 PM', 70);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (71, '60', 49.34, '1/1/2023', '3:23 PM', 71);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (72, '75', 29.72, '2/5/2023', '2:50 AM', 72);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (73, '20', 57.90, '10/19/2022', '11:32 AM', 73);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (74, '73', 28.10, '8/4/2022', '8:23 PM', 74);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (75, '86', 9.25, '3/22/2022', '9:10 PM', 75);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (76, '25', 29.97, '1/1/2023', '8:31 PM', 76);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (77, '53', 12.99, '10/22/2022', '11:19 AM', 77);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (78, '10', 56.36, '6/4/2022', '1:06 PM', 78);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (79, '66', 16.30, '12/13/2022', '10:10 PM', 79);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (80, '44', 61.89, '4/14/2022', '9:06 PM', 80);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (81, '79', 13.36, '10/6/2022', '2:13 PM', 81);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (82, '40', 88.09, '12/27/2022', '2:51 PM', 82);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (83, '67', 48.78, '2/17/2022', '11:53 PM', 83);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (84, '59', 67.80, '2/5/2023', '10:11 AM', 84);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (85, '76', 96.82, '12/18/2022', '3:53 PM', 85);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (86, '3', 64.18, '10/13/2022', '1:19 AM', 86);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (87, '64', 80.89, '6/18/2022', '12:41 AM', 87);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (88, '69', 39.75, '3/27/2022', '12:06 AM', 88);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (89, '68', 79.43, '10/19/2022', '9:11 AM', 89);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (90, '49', 90.49, '8/1/2022', '12:25 AM', 90);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (91, '50', 41.26, '6/8/2022', '12:21 PM', 91);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (92, '95', 71.29, '2/13/2023', '1:04 PM', 92);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (93, '26', 67.98, '9/23/2022', '10:02 PM', 93);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (94, '15', 19.76, '1/24/2023', '6:44 PM', 94);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (95, '6', 56.68, '5/30/2022', '10:54 PM', 95);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (96, '34', 17.95, '3/21/2022', '3:26 PM', 96);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (97, '74', 85.49, '5/21/2022', '1:23 PM', 97);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (98, '38', 30.49, '12/25/2022', '11:34 AM', 98);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (99, '7', 92.50, '11/15/2022', '10:43 PM', 99);
insert into payments (payid, cid, totalprice, paymentdate, paymenttime, oid) values (100, '61', 74.39, '9/10/2022', '12:15 PM', 100);

select *from  payments;
delete from payments where payid=101;
select avg(totalprice)
from payments group by totalprice with rollup;


