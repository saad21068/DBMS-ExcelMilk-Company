-- TRIGGERS
-- 1))

use curds;
select *from cart;
DELIMITER //
CREATE TRIGGER enforce_delivery_period
BEFORE INSERT ON cart
FOR EACH ROW
BEGIN
    IF NEW.deliveryperiod > 7 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Delivery period cannot be greater than 7';
    END IF;
END//

insert into cart (pid, pname, quantity, price, deliveryperiod, productdesc) values (101,'cheese',0, 66.00,9, 'Granite');



-- 2))

create table deleted_customer(
	username VARCHAR(50),
	email VARCHAR(50),
	cid INT,
	address VARCHAR(50),
	contactno VARCHAR(50),
	password VARCHAR(50),
    deletedTime TIMESTAMP DEFAULT NOW()
);

DELIMITER //
create trigger add_deleted_customer
before delete on customer
for each row
begin
	insert into deleted_customer(username, email, cid, address, contactno, password) values(OLD.username,OLD.email,OLD.cid,OLD.address,OLD.contactno,OLD.password);
END //

insert into customer (username, email, cid, address, contactno, password) values ('saad', 'saad@lulu.com', 101, 'IIITD', '8376801800', 'khan');
